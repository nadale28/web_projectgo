package com.book.test1122;

public class Book_info {
	
	private String image;
	private String title;
	private String author;
	private String content;
	
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getImage_source() {
		return image;
	}
	public void setImage_source(String image_source) {
		this.image = image_source;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	

	
}
