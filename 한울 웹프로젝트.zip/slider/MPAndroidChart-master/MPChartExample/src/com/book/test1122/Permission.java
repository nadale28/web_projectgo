package com.book.test1122;

public class Permission {

}
