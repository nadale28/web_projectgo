package com.model;

public class SponsorDTO {
	
	private String jumin1,jumin2,  tel_01,  tel_02,  tel_03,  name,  gen,  mail;
	public String getJumin2() {
		return jumin2;
	}

	public void setJumin2(String jumin2) {
		this.jumin2 = jumin2;
	}

	private String amount;

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getJumin1() {
		return jumin1;
	}

	public void setJumin1(String jumin1) {
		this.jumin1 = jumin1;
	}

	public String getTel_01() {
		return tel_01;
	}

	public void setTel_01(String tel_01) {
		this.tel_01 = tel_01;
	}

	public String getTel_02() {
		return tel_02;
	}

	public void setTel_02(String tel_02) {
		this.tel_02 = tel_02;
	}

	public String getTel_03() {
		return tel_03;
	}

	public void setTel_03(String tel_03) {
		this.tel_03 = tel_03;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGen() {
		return gen;
	}

	public void setGen(String gen) {
		this.gen = gen;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}
	
	
}
